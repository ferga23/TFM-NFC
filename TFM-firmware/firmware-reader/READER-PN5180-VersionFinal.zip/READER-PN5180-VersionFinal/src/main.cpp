#include <Arduino.h>
#include "PN5180.h"
#include "PN5180ISO15693.h"

#if defined(ARDUINO_AVR_UNO) || defined(ARDUINO_AVR_MEGA2560) || defined(ARDUINO_AVR_NANO)

#define PN5180_NSS 10
#define PN5180_BUSY 9
#define PN5180_RST 7

#elif defined(ARDUINO_ARCH_ESP32)

#define PN5180_NSS 16 // swapped with BUSY
#define PN5180_BUSY 5 // swapped with NSS
#define PN5180_RST 17

#else
#error Please define your pinout here!
#endif

PN5180ISO15693 nfc(PN5180_NSS, PN5180_BUSY, PN5180_RST);

void setup()
{
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial.println(F("=================================="));
  Serial.println(F("Uploaded: " __DATE__ " " __TIME__));
  Serial.println(F("PN5180 15693 Demo Sketch"));

  nfc.begin();

  Serial.println(F("----------------------------------"));
  Serial.println(F("PN5180 Hard-Reset..."));
  nfc.reset();

  Serial.println(F("----------------------------------"));
  Serial.println(F("Reading product version..."));
  uint8_t productVersion[2];
  nfc.readEEprom(PRODUCT_VERSION, productVersion, sizeof(productVersion));
  Serial.print(F("Product version="));
  Serial.print(productVersion[1]);
  Serial.print(".");
  Serial.println(productVersion[0]);

  if (0xff == productVersion[1])
  { // if product version 255, the initialization failed
    Serial.println(F("Initialization failed!?"));
    Serial.println(F("Press reset to restart..."));
    Serial.flush();
    exit(-1); // halt
  }

  Serial.println(F("----------------------------------"));
  Serial.println(F("Reading firmware version..."));
  uint8_t firmwareVersion[2];
  nfc.readEEprom(FIRMWARE_VERSION, firmwareVersion, sizeof(firmwareVersion));
  Serial.print(F("Firmware version="));
  Serial.print(firmwareVersion[1]);
  Serial.print(".");
  Serial.println(firmwareVersion[0]);

  Serial.println(F("----------------------------------"));
  Serial.println(F("Reading EEPROM version..."));
  uint8_t eepromVersion[2];
  nfc.readEEprom(EEPROM_VERSION, eepromVersion, sizeof(eepromVersion));
  Serial.print(F("EEPROM version="));
  Serial.print(eepromVersion[1]);
  Serial.print(".");
  Serial.println(eepromVersion[0]);

  Serial.println(F("----------------------------------"));
  Serial.println(F("Enable RF field..."));
  nfc.setupRF();

  Serial.println(F("Setup ready to use."));
}

bool errorFlag = false;

// void myGetInput (void)
// {
//       String inStr = "";
//       if (Serial.available() > 0) {
//       // read the incoming byte:
//       inStr = Serial.readString();
//       // say what you got:
//       Serial.print("I received: ");
//       Serial.println(inStr);
//     }
// }

void myuidprint(uint8_t *uid)
{
  Serial.print(F("Inventory successful, UID=")); // Print the TAG ID
  for (int i = 0; i < 8; i++)
  {
    int j = 0;
    Serial.print(uid[i] < 16 ? "0" : "");
    Serial.print(uid[i], HEX);
    j++;
    if ((j < 2))
    {
      if (i != 7)
      {
        Serial.print(":");
        j = 0;
      }
    }
  }
  Serial.println();
}

void myPrintDataSingle(uint8_t *readBuffer)
{
  for (int i = 0; i < 4; i++)
  {
    if (isprint(readBuffer[i]))
    {
      Serial.print((char)readBuffer[i]);
    }
    else
      Serial.print(" ");
  }
  delay(100);
}

void myPrintData(uint8_t *readBuffer)
{
  for (int i = 0; i < 8*4; i++)
  {
    if (isprint(readBuffer[i]))
    {
      Serial.print((char)readBuffer[i]);
    }
    else
      Serial.print(" ");
  }
  delay(100);
}

void SingleReadFunction(void)
{
  uint8_t uid[8];                               // Array used to save the TAG ID
  ISO15693ErrorCode rc = nfc.getInventory(uid); // I ask the TAG the ID
  if (ISO15693_EC_OK != rc)
  {
    Serial.print(F("Error in getInventory: "));
    Serial.println(nfc.strerror(rc));
    return;
  }
  myuidprint(uid);


  uint8_t blockSize;
  uint16_t numBlocks;
  rc = nfc.getSystemInfo(uid, &blockSize, &numBlocks); // Ask TAG its characteristics and save the data.
  if (ISO15693_EC_OK != rc)
  {
    Serial.print(F(" Error in getSystemInfo: "));
    Serial.println(nfc.strerror(rc));
    errorFlag = true;
    return;
  }

  uint8_t readBuffer[blockSize];
  for (uint16_t no = 0; no < 7; no++) // To each block
  {
    rc = nfc.readSingleBlock(uid, no, readBuffer, blockSize); // Read the data saved in a block

    if (ISO15693_EC_OK != rc)
    {
      Serial.print(F(" Error in readSingleBlock #"));
      Serial.print(no);
      Serial.print(": ");
      Serial.println(nfc.strerror(rc));
      return;
    }
    myPrintDataSingle(readBuffer);

  }
}

void FirstSingleReadFunction(void)
{
  uint8_t uid[8];                               // Array used to save the TAG ID
  ISO15693ErrorCode rc = nfc.getInventory(uid); // I ask the TAG the ID
  if (ISO15693_EC_OK != rc)
  {
    Serial.print(F("Error in getInventory: "));
    Serial.println(nfc.strerror(rc));
    return;
  }
  myuidprint(uid);

  uint8_t blockSize;
  uint16_t numBlocks;
  rc = nfc.getSystemInfo(uid, &blockSize, &numBlocks); // Ask TAG its characteristics and save the data.
  if (ISO15693_EC_OK != rc)
  {
    Serial.print(F(" Error in getSystemInfo: "));
    Serial.println(nfc.strerror(rc));
    errorFlag = true;
    return;
  }

  uint8_t readBuffer[blockSize];
  for (uint16_t no = 0; no < 2; no++) // To each block
  {
    rc = nfc.readSingleBlock(uid, no, readBuffer, blockSize); // Read the data saved in a block

    if (ISO15693_EC_OK != rc)
    {
      Serial.print(F(" Error in readSingleBlock #"));
      Serial.print(no);
      Serial.print(": ");
      Serial.println(nfc.strerror(rc));
      return;
    }
    myPrintDataSingle(readBuffer);
  }
}

void MultipleReadFunction(void)
{
  uint8_t uid[8];                               // Array used to save the TAG ID
  ISO15693ErrorCode rc = nfc.getInventory(uid); // I ask the TAG the ID
  if (ISO15693_EC_OK != rc)
  {
    Serial.print(F("Error in getInventory: "));
    Serial.println(nfc.strerror(rc));
    return;
  }
  myuidprint(uid);

  uint8_t blockSize;
  uint16_t numBlocks;
  rc = nfc.getSystemInfo(uid, &blockSize, &numBlocks); // Ask TAG its characteristics and save the data.
  if (ISO15693_EC_OK != rc)
  {
    Serial.print(F(" Error in getSystemInfo: "));
    Serial.println(nfc.strerror(rc));
    errorFlag = true;
    return;
  }

  uint8_t readBuffer[8 * blockSize];
  rc = nfc.readMultipleBlock(uid, 0, 0, 7, readBuffer, blockSize); // Reads a number of blocks from the TAG

  if (ISO15693_EC_OK != rc)
  {
    Serial.print(F(" Error in readMultipleBlock"));
    Serial.print(": ");
    Serial.println(nfc.strerror(rc));
    errorFlag = true;
    return;
  }
  myPrintData(readBuffer);
}

void OnlyUid(void)
{
  uint8_t uid[8];                               // Array used to save the TAG ID
  ISO15693ErrorCode rc = nfc.getInventory(uid); // I ask the TAG the ID
  if (ISO15693_EC_OK != rc)
  {
    Serial.print(F("Error in getInventory: "));
    Serial.println(nfc.strerror(rc));
    return;
  }
  myuidprint(uid);
}

void InfoTag(void)
{
  uint8_t uid[8];                               // Array used to save the TAG ID
  ISO15693ErrorCode rc = nfc.getInventory(uid); // I ask the TAG the ID
  if (ISO15693_EC_OK != rc)
  {
    Serial.print(F("Error in getInventory: "));
    Serial.println(nfc.strerror(rc));
    return;
  }

  uint8_t blockSize;
  uint16_t numBlocks;
  rc = nfc.getSystemInfo(uid, &blockSize, &numBlocks); // Ask TAG its characteristics and save the data.
  if (ISO15693_EC_OK != rc)
  {
    Serial.print(F(" Error in getSystemInfo: "));
    Serial.println(nfc.strerror(rc));
    errorFlag = true;
    return;
  }
  Serial.print(F("System Info retrieved: blockSize=")); //Print the number of blocks and its size.
  Serial.print(blockSize);
  Serial.print(F(", numBlocks="));
  Serial.println(numBlocks);

}

void loop()
{
  String inStr = "";
  if (Serial.available() > 0)
  {
    // nfc.reset();
    // delay(1000);
    // nfc.setupRF();
    // delay(10);

    inStr = Serial.readString();
    if (inStr == "f")
    {
      Serial.println(F("COMANDO ENCONTRADO"));
      FirstSingleReadFunction();
    }
    else if (inStr == "read")
    {
      Serial.println(F("COMANDO ENCONTRADO"));
      SingleReadFunction();
    }
    else if (inStr == "readm")
    {
      Serial.println(F("COMANDO ENCONTRADO"));
      MultipleReadFunction();
    }
    else if (inStr == "uid")
    {
      Serial.println(F("COMANDO ENCONTRADO"));
      OnlyUid();
    }
    else if (inStr == "info")
    {
      Serial.println(F("COMANDO ENCONTRADO"));
      InfoTag();
    }
    else
    {
      Serial.println(F("ERROR: COMANDO NO ENCONTRADO"));
    }
    delay(100);
    Serial.println();
    Serial.println(F("Reader ready"));
  }
}

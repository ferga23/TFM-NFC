/**
  ******************************************************************************
  * @file    m24lr-i2c.c
  * @author  MMY Application Team
  * @version $Revision: 1580 $
  * @date    $Date: 2016-02-03 14:49:28 +0100 (Wed, 03 Feb 2016) $
  * @brief   This file provides Modelo v0.1 shield board
  *          specific functions
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2015 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "m24lr-eeprom.h"
#include "m24lr-i2c.h"

/** @addtogroup BSP
 * @{
 */

/** @defgroup X_NUCLEO_NFC02A1
 * @{
 */
/* Private typedef -----------------------------------------------------------*/
/* Private defines -----------------------------------------------------------*/
/* Private macros ------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Global variables ----------------------------------------------------------*/
/** @defgroup X_NUCLEO_NFC02A1_Global_Variables
 * @{
 */
//NFC02A1_Led_TypeDef NFC02A1_Led[3] = { { NFC02A1_LED1_PIN, NFC02A1_LED1_PIN_PORT } ,
//                                       { NFC02A1_LED2_PIN, NFC02A1_LED2_PIN_PORT } ,
//                                       { NFC02A1_LED3_PIN, NFC02A1_LED3_PIN_PORT } };

//static I2C_HandleTypeDef hNFC02A1_i2c;
static I2C_HandleTypeDef hi2c1;

/**
 * @}
 */

/* Private function prototypes -----------------------------------------------*/
static HAL_StatusTypeDef STM32_I2C1_Init( void );
static HAL_StatusTypeDef STM32_I2C1_DeInit( void );
static HAL_StatusTypeDef STM32_I2C1_MemWrite( const uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size );
static HAL_StatusTypeDef STM32_I2C1_Write( const uint8_t * const pData, const uint8_t DevAddr, const uint16_t Size );
static HAL_StatusTypeDef STM32_I2C1_MemRead( uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size );
static HAL_StatusTypeDef STM32_I2C1_Read( uint8_t * const pData, const uint8_t DevAddr, const uint16_t Size );
static HAL_StatusTypeDef STM32_I2C1_IsDeviceReady( const uint8_t DevAddr, const uint32_t Trials );
//static void STM32_I2C1_MspInit( void );

static NFCTAG_StatusTypeDef NFCTAG_IO_Init( void );
static NFCTAG_StatusTypeDef NFCTAG_IO_DeInit( void );
NFCTAG_StatusTypeDef NFCTAG_IO_MemWrite( const uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size );
NFCTAG_StatusTypeDef NFCTAG_IO_Write( const uint8_t * const pData, const uint8_t DevAddr, const uint16_t Size );
NFCTAG_StatusTypeDef NFCTAG_IO_MemRead( uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size );
NFCTAG_StatusTypeDef NFCTAG_IO_Read( uint8_t * const pData, const uint8_t DevAddr, const uint16_t Size );
NFCTAG_StatusTypeDef NFCTAG_IO_IsDeviceReady( const uint8_t DevAddr, const uint32_t Trials );

NFCTAG_StatusTypeDef M24lr_IO_Init( void );
NFCTAG_StatusTypeDef M24lr_IO_DeInitialize( void );
NFCTAG_StatusTypeDef M24lr_IO_MemWrite( const uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size );
NFCTAG_StatusTypeDef M24lr_IO_MemRead( uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size );

NFCTAG_StatusTypeDef NFCTAG_ConvertStatus( const HAL_StatusTypeDef status );

/* Functions Definition ------------------------------------------------------*/
/******************************** LINK EEPROM COMPONENT *****************************/

/**
  * @brief  Initializes peripherals used by the I2C NFCTAG driver
  * @param  None
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef M24lr_IO_Init( void )
{
  return NFCTAG_IO_Init( );
}

/**
  * @brief  Denitializes peripherals used by the I2C NFCTAG driver
  * @param  None
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef M24lr_IO_DeInitialize( void )
{
  return NFCTAG_IO_DeInit( );
}

/**
  * @brief  Write data, at specific address, through i2c to the M24LR
  * @param  pData: pointer to the data to write
  * @param  DevAddr : Target device address
  * @param  TarAddr : I2C data memory address to write
  * @param  Size : Size in bytes of the value to be written
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef M24lr_IO_MemWrite( const uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size )
{
  return NFCTAG_IO_MemWrite( pData, DevAddr, TarAddr, Size );
}

/**
  * @brief  Reads a byte from the NFCTAG.
  * @param  pData: pointer to store read data
  * @param  DevAddr : Target device address
  * @param  TarAddr : I2C data memory address to read
  * @param  Size : Size in bytes of the value to be read
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef M24lr_IO_MemRead( uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size )
{
  return NFCTAG_IO_MemRead( pData, DevAddr, TarAddr, Size );
}

/**
* @brief  Checks if target device is ready for communication
* @note   This function is used with Memory devices
* @param  DevAddr : Target device address
* @param  Trials : Number of trials
* @retval NFCTAG enum status
*/
NFCTAG_StatusTypeDef M24lr_IO_IsDeviceReady( const uint8_t DevAddr, const uint32_t Trials )
{
  return NFCTAG_IO_IsDeviceReady( DevAddr, Trials );
}

/******************************** LINK NFCTAG *****************************/
/**
  * @brief  This functions converts HAL status to NFCTAG status
  * @param  status : HAL status to convert
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef NFCTAG_ConvertStatus( const HAL_StatusTypeDef status )
{
  switch( status )
  {
    case HAL_OK:
      return NFCTAG_OK;
    case HAL_ERROR:
      return NFCTAG_ERROR;
    case HAL_BUSY:
      return NFCTAG_BUSY;
    case HAL_TIMEOUT:
      return NFCTAG_TIMEOUT;

    default:
      return NFCTAG_TIMEOUT;
  }
}

/**
  * @brief  Configures nfctag I2C interface
  * @param  None
  * @retval NFCTAG enum status
  */
static NFCTAG_StatusTypeDef NFCTAG_IO_Init( void )
{
  return NFCTAG_ConvertStatus( STM32_I2C1_Init( ) );
}

/**
  * @brief  Deconfigures nfctag I2C interface
  * @param  None
  * @retval NFCTAG enum status
  */
static NFCTAG_StatusTypeDef NFCTAG_IO_DeInit( void )
{
  return NFCTAG_ConvertStatus( STM32_I2C1_DeInit( ) );
}

/**
  * @brief  Write at specific address nfctag memory
  * @param  pData : pointer to the data to write
  * @param  DevAddr : Target device address
  * @param  TarAddr : I2C data memory address to write
  * @param  Size : Size in bytes of the value to be written
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef NFCTAG_IO_MemWrite( const uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size )
{
  return NFCTAG_ConvertStatus( STM32_I2C1_MemWrite( pData, DevAddr, TarAddr, Size ) );
}

/**
  * @brief  Write at current address nfctag memory
  * @param  pData : pointer to the data to write
  * @param  DevAddr : Target device address
  * @param  Size : Size in bytes of the value to be written
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef NFCTAG_IO_Write( const uint8_t * const pData, const uint8_t DevAddr, const uint16_t Size )
{
  return NFCTAG_ConvertStatus( STM32_I2C1_Write( pData, DevAddr, Size ) );
}

/**
  * @brief  Read at specific address on nfctag
  * @param  pData : pointer to store read data
  * @param  DevAddr : Target device address
  * @param  TarAddr : I2C data memory address to read
  * @param  Size : Size in bytes of the value to be read
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef NFCTAG_IO_MemRead( uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size )
{
  return NFCTAG_ConvertStatus( STM32_I2C1_MemRead( pData, DevAddr, TarAddr, Size ) );
}

/**
  * @brief  Read at current address on nfctag
  * @param  pData : pointer to store read data
  * @param  DevAddr : Target device address
  * @param  Size : Size in bytes of the value to be read
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef NFCTAG_IO_Read( uint8_t * const pData, const uint8_t DevAddr, const uint16_t Size )
{
  return NFCTAG_ConvertStatus( STM32_I2C1_Read( pData, DevAddr, Size ) );
}

/**
  * @brief  Check nfctag availability
  * @param  DevAddr : Target device address
  * @param  Trials : Number of trials
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef NFCTAG_IO_IsDeviceReady( const uint8_t DevAddr, const uint32_t Trials )
{
  return NFCTAG_ConvertStatus( STM32_I2C1_IsDeviceReady( DevAddr, Trials ) );
}



/******************************************************************************
                            BUS OPERATIONS
*******************************************************************************/
/**
  * @brief  Configures I2C interface.
  * @param  None
  * @retval HAL status
  */
static HAL_StatusTypeDef STM32_I2C1_Init( void )
{
  HAL_StatusTypeDef ret_val = HAL_OK;

  hi2c1.Instance = I2C1;
    hi2c1.Init.Timing = 0x00000708;
    hi2c1.Init.OwnAddress1 = 0;
    hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2 = 0;
    hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
    if (HAL_I2C_Init(&hi2c1) != HAL_OK)
    {
    	while(1){}
    }

    /** Configure Analogue filter
    */
    if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
    {
      while(1){}
    }

    /** Configure Digital filter
    */
    if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
    {
    	while(1){}
    }

  return ret_val;
}

/**
  * @brief  Deconfigures I2C interface.
  * @param  None
  * @retval HAL status
  */
static HAL_StatusTypeDef STM32_I2C1_DeInit( void )
{
	HAL_StatusTypeDef ret_val = HAL_OK;

	HAL_I2C_DeInit(&hi2c1);

	return ret_val;
}

/**
  * @brief  Write data in a register of the device through the bus
  * @param  pData : pointer to the data to write
  * @param  DevAddr : Target device address
  * @param  TarAddr : I2C data memory address to write
  * @param  Size : Size in bytes of the value to be written
  * @retval HAL status
  */

static HAL_StatusTypeDef STM32_I2C1_MemWrite( const uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size )
{
  uint8_t *pbuffer = (uint8_t *)pData;

  return HAL_I2C_Mem_Write( &hi2c1, DevAddr, TarAddr, I2C_MEMADD_SIZE_16BIT, pbuffer, Size, NFCTAG_I2C_TIMEOUT );
}

/**
  * @brief  Write data in a register of the device through the bus
  * @param  pData : pointer to the data to write
  * @param  DevAddr : Target device address
  * @param  Size : Size in bytes of the value to be written
  * @retval HAL status
  */

static HAL_StatusTypeDef STM32_I2C1_Write( const uint8_t * const pData, const uint8_t DevAddr, const uint16_t Size )
{
  uint8_t *pbuffer = (uint8_t *)pData;

  return HAL_I2C_Master_Transmit( &hi2c1, DevAddr, pbuffer, Size, NFCTAG_I2C_TIMEOUT );
}

/**
  * @brief  Read the value of a register of the device through the bus
  * @param  pData : pointer to store read data
  * @param  DevAddr : Target device address
  * @param  TarAddr : I2C data memory address to read
  * @param  Size : Size in bytes of the value to be read
  * @retval HAL status.
  */
static HAL_StatusTypeDef STM32_I2C1_MemRead( uint8_t * const pData, const uint8_t DevAddr, const uint16_t TarAddr, const uint16_t Size )
{
  uint8_t *pbuffer = (uint8_t *)pData;

  return HAL_I2C_Mem_Read( &hi2c1, DevAddr, TarAddr, I2C_MEMADD_SIZE_16BIT, pbuffer, Size, NFCTAG_I2C_TIMEOUT );
}

/**
  * @brief  Read the value of a register of the device through the bus
  * @param  pData : pointer to store read data
  * @param  DevAddr : the device address on bus
  * @param  Size : Size in bytes of the value to be read
  * @retval HAL status
  */
static HAL_StatusTypeDef STM32_I2C1_Read( uint8_t * const pData, const uint8_t DevAddr, const uint16_t Size )
{
  uint8_t *pbuffer = (uint8_t *)pData;

  return HAL_I2C_Master_Receive( &hi2c1, DevAddr, pbuffer, Size, NFCTAG_I2C_TIMEOUT );
}

/**
* @brief  Checks if target device is ready for communication
* @note   This function is used with Memory devices
* @param  DevAddr : Target device address
* @param  Trials : Number of trials
* @retval HAL status
*/
static HAL_StatusTypeDef STM32_I2C1_IsDeviceReady( const uint8_t DevAddr, const uint32_t Trials )
{
	return HAL_I2C_IsDeviceReady( &hi2c1, DevAddr, Trials, NFCTAG_I2C_TIMEOUT );
}


/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/

/**
  ******************************************************************************
  * @file    m24lr-eeprom.c
  * @author  MMY Application Team
  * @version $Revision: 1580 $
  * @date    $Date: 2016-02-03 14:49:28 +0100 (Wed, 03 Feb 2016) $
  * @brief   This file provides a set of functions needed to manage a nfc dual
  *          interface eeprom memory.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2015 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "m24lr-eeprom.h"

/** @addtogroup BSP
 * @{
 */

/** @addtogroup X_NUCLEO_NFC02A1
 * @{
 */

/** @defgroup X_NUCLEO_NFC02A1_NFCTAG
 * @{
 */
/* Private typedef -----------------------------------------------------------*/
/* Private defines -----------------------------------------------------------*/
/** @defgroup X_NUCLEO_NFC02A1_NFCTAG_Private_Defines
 * @{
 */
#ifndef NULL
#define NULL      (void *) 0
#endif
/**
 * @}
 */

/* Private macros ------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Global variables ----------------------------------------------------------*/
/** @defgroup X_NUCLEO_NFC02A1_NFCTAG_Private_Variables
 * @{
 */
static NFCTAG_DrvTypeDef *Nfctag_Drv = NULL;
static uint8_t NfctagInitialized = 0;
/**
 * @}
 */
/* Private function prototypes -----------------------------------------------*/
/* Functions Definition ------------------------------------------------------*/
/** @defgroup X_NUCLEO_NFC02A1_NFCTAG_Public_Functions
 * @{
 */
/**
  * @brief  Initializes peripherals used by the I2C NFCTAG driver
  * @param  None
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef BSP_NFCTAG_Init( void )
{
  uint8_t nfctag_id = 0;

  if( !NfctagInitialized )
  {

    if( M24lr_i2c_Drv.Init == NULL )
    {
      return NFCTAG_ERROR;
    }

    /* M24LR Init */
    if( M24lr_i2c_Drv.Init() != NFCTAG_OK )
    {
      return NFCTAG_ERROR;
    }

    /* Check M24LR driver ID */
    M24lr_i2c_Drv.ReadID(&nfctag_id);
    if( (nfctag_id == I_AM_M24LR04) || (nfctag_id == I_AM_M24LR16) || (nfctag_id == I_AM_M24LR64) )
    {
      NfctagInitialized = 1;
      Nfctag_Drv = &M24lr_i2c_Drv;
      Nfctag_Drv->pData = &M24lr_i2c_ExtDrv;
    }
    else
    {
      Nfctag_Drv = NULL;
      NfctagInitialized = 0;
      return NFCTAG_ERROR;
    }
  }

  return NFCTAG_OK;
}

/**
  * @brief  Check if the nfctag is initialized
  * @param  None
  * @retval 0 if the nfctag is not initialized, 1 if the nfctag is already initialized
  */
uint8_t BSP_NFCTAG_isInitialized( void )
{
  return NfctagInitialized;
}

/**
  * @brief  Deinitializes peripherals used by the I2C NFCTAG driver
  * @param  None
  * @retval NFCTAG enum status
  */

NFCTAG_StatusTypeDef BSP_NFCTAG_DeInit( void )
{
    /* M24LR DeInit */
    if( M24lr_i2c_Drv.DeInit() != NFCTAG_OK )
    {
      return NFCTAG_ERROR;
    }

    return NFCTAG_OK;
}

/**
  * @brief  Read the ID of the nfctag
  * @param  wai_id : the pointer where the who_am_i of the device is stored
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef BSP_NFCTAG_ReadID( uint8_t * const wai_id )
{
  if ( Nfctag_Drv->ReadID == NULL )
  {
    return NFCTAG_ERROR;
  }

  return Nfctag_Drv->ReadID( wai_id );
}

/**
  * @brief  Return the size of the nfctag
  * @retval Size of the NFCtag in Bytes
  */
uint32_t BSP_NFCTAG_GetByteSize( void )
{
  M24LR_Mem_Size mem_size;
  ((NFCTAG_ExtDrvTypeDef *)Nfctag_Drv->pData)->ReadMemSize( &mem_size );

  return (mem_size.BlockSize+1) * (mem_size.Mem_Size+1);
}

/**
  * @brief  Check if the nfctag is available
  * @param  Trials : Number of trials
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef BSP_NFCTAG_IsDeviceReady( const uint32_t Trials )
{
  if ( Nfctag_Drv->IsReady == NULL )
  {
    return NFCTAG_ERROR;
  }

  return Nfctag_Drv->IsReady( Trials );
}

/**
  * @brief  Configure nfctag interrupt
  * @param  ITConfig : store interrupt to configure
  *                  - 0x01 => RF BUSY
  *                  - 0x02 => WIP
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef BSP_NFCTAG_ConfigIT( const uint16_t ITConfig )
{
  if ( Nfctag_Drv->ConfigIT == NULL )
  {
    return NFCTAG_ERROR;
  }

  return Nfctag_Drv->ConfigIT( ITConfig );
}

/**
  * @brief  Get nfctag interrupt configuration
  * @param  ITConfig : store interrupt configuration
  *                  - 0x01 => RF BUSY
  *                  - 0x02 => WIP
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef BSP_NFCTAG_GetITStatus( uint16_t * const ITConfig )
{
  if ( Nfctag_Drv->GetITStatus == NULL )
  {
    return NFCTAG_ERROR;
  }

  return Nfctag_Drv->GetITStatus( ITConfig );
}

/**
  * @brief  Reads data in the nfctag at specific address
  * @param  pData : pointer to store read data
  * @param  TarAddr : I2C data memory address to read
  * @param  Size : Size in bytes of the value to be read
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef BSP_NFCTAG_ReadData( uint8_t * const pData, const uint16_t TarAddr, const uint16_t Size )
{
  if ( Nfctag_Drv->ReadData == NULL )
  {
    return NFCTAG_ERROR;
  }

  return Nfctag_Drv->ReadData( pData, TarAddr, Size );
}

/**
  * @brief  Writes data in the nfctag at specific address
  * @param  pData : pointer to the data to write
  * @param  TarAddr : I2C data memory address to write
  * @param  Size : Size in bytes of the value to be written
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef BSP_NFCTAG_WriteData( const uint8_t * const pData, const uint16_t TarAddr, const uint16_t Size )
{
  NFCTAG_StatusTypeDef ret_value;
  if ( Nfctag_Drv->WriteData == NULL )
  {
    return NFCTAG_ERROR;
  }

  ret_value = Nfctag_Drv->WriteData( pData, TarAddr, Size );
  if( ret_value == NFCTAG_OK )
  {
    while( BSP_NFCTAG_IsDeviceReady( 1 ) != NFCTAG_OK ) {};
      return NFCTAG_OK;
  }

  return ret_value;
}

/**
  * @brief  Reads nfctag Register
  * @param  pData : pointer to store read data
  * @param  TarAddr : I2C register address to read
  * @param  Size : Size in bytes of the value to be read
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef BSP_NFCTAG_ReadRegister( uint8_t * const pData, const uint16_t TarAddr, const uint16_t Size )
{
  if ( Nfctag_Drv->ReadRegister == NULL )
  {
    return NFCTAG_ERROR;
  }

  return Nfctag_Drv->ReadRegister( pData, TarAddr, Size );
}

/**
  * @brief  Writes nfctag Register
  * @param  pData : pointer to the data to write
  * @param  TarAddr : I2C register address to write
  * @param  Size : Size in bytes of the value to be written
  * @retval NFCTAG enum status
  */
NFCTAG_StatusTypeDef BSP_NFCTAG_WriteRegister( const uint8_t * const pData, const uint16_t TarAddr, const uint16_t Size )
{
  NFCTAG_StatusTypeDef ret_value;
  if ( Nfctag_Drv->WriteRegister == NULL )
  {
    return NFCTAG_ERROR;
  }

  ret_value = Nfctag_Drv->WriteRegister( pData, TarAddr, Size );
  if( ret_value == NFCTAG_OK )
  {
    while( BSP_NFCTAG_IsDeviceReady( 1 ) != NFCTAG_OK ) {};
      return NFCTAG_OK;
  }

  return ret_value;
}

/**
  * @brief  Give extended features for component
  * @param  None
  * @retval address of the Extended Component Structure
  */
NFCTAG_ExtDrvTypeDef *BSP_NFCTAG_GetExtended_Drv( void )
{
  return (NFCTAG_ExtDrvTypeDef *)Nfctag_Drv->pData;
}

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/

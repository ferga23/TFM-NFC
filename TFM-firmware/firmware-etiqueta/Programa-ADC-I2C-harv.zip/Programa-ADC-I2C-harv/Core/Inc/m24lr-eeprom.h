/**
  ******************************************************************************
  * @file    x_nucleo_nfc02a1_nfctag.h
  * @author  MMY Application Team
  * @version $Revision: 1580 $
  * @date    $Date: 2016-02-03 14:49:28 +0100 (Wed, 03 Feb 2016) $
  * @brief   This file contains definitions for the x_nucleo_nfc02a1_nfctag.c
  *          specific functions.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2015 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef INC_M24LR_EEPROM_H_
#define INC_M24LR_EEPROM_H_

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "m24lr-i2c.h"

/** @addtogroup BSP
  * @{
  */

/** @addtogroup X_NUCLEO_NFC02A1
  * @{
  */

/** @addtogroup X_NUCLEO_NFC02A1_NFCTAG
  * @{
  */
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
#define NFCTAG_4K_SIZE            0x200
#define NFCTAG_16K_SIZE           0x800
#define NFCTAG_64K_SIZE           0x2000
/* External variables --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported function	--------------------------------------------------------*/
/** @defgroup X_NUCLEO_NFC02A1_NFCTAG_Exported_Functions
  * @{
  */
NFCTAG_StatusTypeDef BSP_NFCTAG_Init( void );
NFCTAG_StatusTypeDef BSP_NFCTAG_DeInit( void );
uint8_t BSP_NFCTAG_isInitialized( void );
NFCTAG_StatusTypeDef BSP_NFCTAG_ReadID( uint8_t * const wai_id );
uint32_t BSP_NFCTAG_GetByteSize( void );
NFCTAG_StatusTypeDef BSP_NFCTAG_IsDeviceReady( const uint32_t Trials );
NFCTAG_StatusTypeDef BSP_NFCTAG_ConfigIT( const uint16_t ITConfig );
NFCTAG_StatusTypeDef BSP_NFCTAG_GetITStatus( uint16_t * const ITConfig );
NFCTAG_StatusTypeDef BSP_NFCTAG_ReadData( uint8_t * const pData, const uint16_t TarAddr, const uint16_t Size );
NFCTAG_StatusTypeDef BSP_NFCTAG_WriteData( const uint8_t * const pData, const uint16_t TarAddr, const uint16_t Size );
NFCTAG_StatusTypeDef BSP_NFCTAG_ReadRegister( uint8_t * const pData, const uint16_t TarAddr, const uint16_t Size );
NFCTAG_StatusTypeDef BSP_NFCTAG_WriteRegister( const uint8_t * const pData, const uint16_t TarAddr, const uint16_t Size );
NFCTAG_ExtDrvTypeDef *BSP_NFCTAG_GetExtended_Drv( void );
/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif /* INC_M24LR_EEPROM_H_ */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
